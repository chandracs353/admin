Free Admin Template with Twitter Bootstrap
------------------------------------------

### Installation
(for 1.2 version only)

    $ git clone -b v1.2 https://github.com/onokumus/Bootstrap-Admin-Template.git yourfoldername
    $ cd yourfoldername
    $ git submodule init
    $ git submodule update

### Demo

[http://demo.onokumus.com/metis/v12](http://demo.onokumus.com/metis/v12)

### Licensing

Bootstrap Admin template is open-sourced software licensed under the [MIT License](http://opensource.org/licenses/MIT)


[Buy me a coffee?](https://wrapbootstrap.com/theme/nuro-theme-WB0628X10)
